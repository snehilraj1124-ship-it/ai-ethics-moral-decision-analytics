# Key Metrics

- Scenario count
- Average risk
- Average human impact
- Average fairness
- Average transparency
- Average autonomy
- Average accountability
- Average privacy
- Average utility
- Framework score averages
- Overall ethics index
- Risk-adjusted ethics index
