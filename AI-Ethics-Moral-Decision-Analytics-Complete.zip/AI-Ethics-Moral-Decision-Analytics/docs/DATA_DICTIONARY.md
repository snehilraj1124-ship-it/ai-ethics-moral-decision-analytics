# Data Dictionary

| Field | Description |
|---|---|
| case_id | Synthetic decision-case identifier |
| scenario | AI application scenario |
| risk_score | Simulated decision risk |
| human_impact_score | Potential human impact |
| fairness_score | Fairness indicator |
| transparency_score | Explainability/transparency indicator |
| autonomy_score | Respect for human autonomy |
| accountability_score | Accountability indicator |
| privacy_score | Privacy protection indicator |
| utility_score | Expected social utility |
| utilitarian_score | Analytical utilitarianism score |
| deontological_score | Analytical duty/rule-based score |
| virtue_ethics_score | Analytical virtue-ethics score |
| justice_score | Analytical justice/fairness score |
| overall_ethics_index | Composite analytical index |
| recommended_framework | Framework with highest score |
