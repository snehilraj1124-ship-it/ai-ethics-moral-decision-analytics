# Methodology

## 1. Scenario Generation
Synthetic AI ethics cases are generated across six application domains.

## 2. Ethical Dimensions
Each case contains numerical indicators for risk, human impact, fairness, transparency, autonomy, accountability, privacy and utility.

## 3. Philosophical Frameworks
Each framework is operationalized using weighted dimensions.

### Utilitarianism
Emphasizes utility and aggregate human impact.

### Deontology
Emphasizes duties, autonomy, privacy and accountability.

### Virtue Ethics
Emphasizes fairness, accountability, transparency and human impact.

### Justice
Emphasizes fairness, privacy, accountability and transparency.

## 4. Composite Index
An overall ethics index combines the four framework scores.

## 5. Risk Adjustment
A separate risk-adjusted metric subtracts a weighted risk component.

These formulas are project-specific analytical abstractions and are not authoritative philosophical definitions.
