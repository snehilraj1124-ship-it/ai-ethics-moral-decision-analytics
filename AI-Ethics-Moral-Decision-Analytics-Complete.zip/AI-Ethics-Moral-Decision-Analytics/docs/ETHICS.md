# Responsible AI Ethics

This project does not attempt to automate morality.

Important principles:

- Ethical scores are analytical abstractions.
- No real individual is evaluated.
- No high-stakes decision should rely on these scores.
- Philosophical theories can conflict.
- Different societies may assign different moral priorities.
- Human oversight remains essential.

The dataset is synthetic to avoid privacy concerns.
