# Case Study Categories

## Autonomous Vehicles
Questions involving safety, risk, responsibility and human life.

## Hiring Algorithms
Questions involving fairness, discrimination, transparency and accountability.

## Healthcare Triage
Questions involving utility, equality, privacy and human autonomy.

## Content Moderation
Questions involving free expression, harm prevention and platform responsibility.

## Credit Decisions
Questions involving fairness, explainability, privacy and economic impact.

## Facial Recognition
Questions involving privacy, surveillance, security and accountability.
