# Research Questions

1. Do ethical frameworks evaluate the same AI scenario differently?
2. Which dimensions most strongly correlate with the overall ethics index?
3. Which framework is most frequently the highest-scoring framework in the synthetic sample?
4. How does risk adjustment change analytical scores?
5. Do scenario categories exhibit different ethical profiles?
