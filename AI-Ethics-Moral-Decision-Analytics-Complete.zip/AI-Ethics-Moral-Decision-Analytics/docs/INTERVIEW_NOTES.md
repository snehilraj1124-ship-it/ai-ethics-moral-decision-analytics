# Interview Notes

### Short Explanation

I built an AI ethics analytics project that translates selected philosophical frameworks into transparent analytical dimensions and tests them across simulated AI decision scenarios.

### Why?

I wanted to explore the intersection of technology, philosophy, ethics and data analytics.

### Important Caveat

The scores are not objective measurements of morality. They are a way to make assumptions explicit and compare scenarios consistently.
