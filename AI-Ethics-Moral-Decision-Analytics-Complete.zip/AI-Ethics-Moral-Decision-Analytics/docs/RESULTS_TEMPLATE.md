# Results Template

## Descriptive Analysis
Summarize scenario distributions.

## Framework Comparison
Compare the four analytical framework scores.

## Correlation
Analyze relationships among ethical dimensions.

## Scenario Analysis
Compare ethical profiles across application domains.

## Interpretation
Discuss competing values without claiming one framework is universally correct.
