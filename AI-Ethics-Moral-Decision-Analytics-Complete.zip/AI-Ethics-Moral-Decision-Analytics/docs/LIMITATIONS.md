# Limitations

1. Dataset is synthetic.
2. Philosophical theories are simplified into numerical variables.
3. Weight choices are subjective.
4. Ethical reasoning cannot be fully captured by a single index.
5. Frameworks can produce conflicting conclusions.
6. Numerical rankings may create false precision.
7. Results cannot be generalized to real AI systems.
