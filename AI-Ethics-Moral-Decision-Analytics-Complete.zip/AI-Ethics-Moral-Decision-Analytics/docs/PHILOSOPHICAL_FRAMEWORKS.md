# Philosophical Frameworks

## Utilitarianism
Evaluates actions by their consequences and aggregate utility.

## Deontology
Evaluates actions through duties, rules, rights and constraints rather than consequences alone.

## Virtue Ethics
Focuses on character, virtues and what a morally good agent would do.

## Justice/Fairness
Focuses on equitable treatment, distribution, rights and procedural fairness.

The project uses simplified numerical proxies to compare frameworks. Real philosophical reasoning is richer than any scoring system.
