import pandas as pd
df=pd.read_csv('../data/processed/ethical_decision_features.csv')
print(df[['overall_ethics_index','risk_adjusted_ethics']].describe())
