import pandas as pd
df=pd.read_csv('../data/raw/ai_ethics_decision_dataset.csv')
corr=df.select_dtypes('number').corr().round(3)
corr.to_csv('../reports/correlation_matrix.csv')
print(corr)
