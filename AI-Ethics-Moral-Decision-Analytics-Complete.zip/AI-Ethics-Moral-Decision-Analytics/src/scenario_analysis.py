import pandas as pd
df=pd.read_csv('../data/raw/ai_ethics_decision_dataset.csv')
cols=['risk_score','fairness_score','transparency_score','autonomy_score','accountability_score','privacy_score','utility_score','overall_ethics_index']
df.groupby('scenario')[cols].mean().round(2).to_csv('../reports/scenario_summary.csv')
