import pandas as pd
raw=pd.read_csv('../data/raw/ai_ethics_decision_dataset.csv')
processed=pd.read_csv('../data/processed/ethical_decision_features.csv')
with pd.ExcelWriter('../reports/ai_ethics_analytics.xlsx') as w:
    raw.to_excel(w,sheet_name='Raw_Data',index=False)
    processed.to_excel(w,sheet_name='Processed_Data',index=False)
    raw.select_dtypes('number').describe().T.to_excel(w,sheet_name='Descriptive_Stats')
    raw.select_dtypes('number').corr().to_excel(w,sheet_name='Correlations')
    raw.groupby('scenario').mean(numeric_only=True).to_excel(w,sheet_name='Scenario_Summary')
