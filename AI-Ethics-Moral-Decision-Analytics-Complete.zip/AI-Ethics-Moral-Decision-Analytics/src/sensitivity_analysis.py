import pandas as pd
df=pd.read_csv('../data/raw/ai_ethics_decision_dataset.csv')
frameworks=['utilitarian_score','deontological_score','virtue_ethics_score','justice_score']
for w in [.20,.25,.30,.35]:
    score=w*df['utilitarian_score']+(1-w)*df['justice_score']
    print('Utility weight',w,'mean',round(score.mean(),2))
