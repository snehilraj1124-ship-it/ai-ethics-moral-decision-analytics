import pandas as pd
df=pd.read_csv('../data/raw/ai_ethics_decision_dataset.csv')
print('Shape:',df.shape)
print('Missing:',df.isna().sum().sum())
print('Duplicates:',df.duplicated().sum())
