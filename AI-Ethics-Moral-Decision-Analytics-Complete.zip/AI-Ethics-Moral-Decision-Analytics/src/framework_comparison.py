import pandas as pd
df=pd.read_csv('../data/raw/ai_ethics_decision_dataset.csv')
cols=['utilitarian_score','deontological_score','virtue_ethics_score','justice_score']
print(df[cols].mean().round(2))
print(df.groupby('scenario')[cols].mean().round(2))
