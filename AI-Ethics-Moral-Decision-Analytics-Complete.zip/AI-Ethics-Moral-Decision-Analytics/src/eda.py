import pandas as pd
df=pd.read_csv('../data/raw/ai_ethics_decision_dataset.csv')
print(df.describe(include='all').T)
print(df['scenario'].value_counts())
