import pandas as pd
df=pd.read_csv('../data/raw/ai_ethics_decision_dataset.csv')
df.select_dtypes('number').describe().T.to_csv('../reports/descriptive_statistics.csv')
