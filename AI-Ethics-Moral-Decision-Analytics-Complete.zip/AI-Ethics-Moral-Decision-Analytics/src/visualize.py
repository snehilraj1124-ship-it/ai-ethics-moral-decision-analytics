import pandas as pd
import matplotlib.pyplot as plt
df=pd.read_csv('../data/raw/ai_ethics_decision_dataset.csv')
cols=['utilitarian_score','deontological_score','virtue_ethics_score','justice_score']
df[cols].mean().plot(kind='bar')
plt.ylabel('Average Analytical Score')
plt.title('Ethical Framework Comparison')
plt.tight_layout()
plt.savefig('../visualizations/framework_comparison.png',dpi=160)
plt.close()

plt.figure(figsize=(9,6))
plt.scatter(df['risk_score'],df['overall_ethics_index'],alpha=.5)
plt.xlabel('Risk Score');plt.ylabel('Overall Ethics Index')
plt.title('Risk vs Overall Ethics Index')
plt.tight_layout()
plt.savefig('../visualizations/risk_vs_ethics.png',dpi=160)
plt.close()
