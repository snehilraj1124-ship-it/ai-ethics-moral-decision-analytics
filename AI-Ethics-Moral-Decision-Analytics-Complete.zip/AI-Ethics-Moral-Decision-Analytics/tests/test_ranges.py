import pandas as pd
def test_scores():
    df=pd.read_csv('../data/raw/ai_ethics_decision_dataset.csv')
    cols=['risk_score','fairness_score','transparency_score','autonomy_score','accountability_score','privacy_score','utility_score']
    for c in cols:
        assert df[c].between(1,10).all()
