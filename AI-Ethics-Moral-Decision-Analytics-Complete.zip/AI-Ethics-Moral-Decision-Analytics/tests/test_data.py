import pandas as pd
def test_dataset_size():
    assert len(pd.read_csv('../data/raw/ai_ethics_decision_dataset.csv'))==1000
def test_required_columns():
    df=pd.read_csv('../data/raw/ai_ethics_decision_dataset.csv')
    assert all(c in df.columns for c in ['fairness_score','privacy_score','overall_ethics_index'])
