# Dataset Information

The dataset contains 1,000 synthetic AI ethics decision cases.

No real people, organizations or production AI systems are represented.

The data was generated to demonstrate how ethical assumptions can be represented explicitly and analyzed computationally.
